<?php

require_once 'DatabaseMysql.php';

$ra = $_POST['ra'] ?? 'ra não informardo';
$nome = $_POST['nome'] ?? 'aluno não informardo';
$sobrenome = $_POST['sobrenome'] ?? 'sobrenome não informardo';
$curso = $_POST['curso'] ?? 'curso não informardo';
$email = $_POST['email'] ?? 'email não informardo';
$cidade = $_POST['cidade'] ?? 'cidade não informardo';
$ano_ingresso = $_POST['ano_ingresso'] ?? 'ano_ingresso não informardo';
$flagg = $_GET['flagg'];

$db = new Database();

if ($flagg == 'D') {

    $id = $_GET['id'];
    $sql = "DELETE FROM alunos 
                WHERE id = ?";
    if ($db->executa_comando($sql, [$id])) {
        echo "<p>Dados excluídos com sucesso do banco de dados!</p>";
    } else {
        echo "<p>Erro ao excluir os dados do banco.</p>";
    }
    header('Location: alunos.php');
    exit;

}

$flag = $_POST['flag'];
$id = $_POST['id'];

if ($flag == 'I') {

    $sql = "INSERT INTO alunos (
                   ra, nome, sobrenome, curso, email, cidade, ano_ingresso
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?
                )";

    if ($db->executa_comando($sql, [$ra, $nome, $sobrenome, $curso, $email, $cidade, $ano_ingresso])) {
        echo "<p>Dados inseridos com sucesso no banco de dados!</p>";
    } else {
        echo "<p>Erro ao inserir os dados no banco.</p>";
    }
    header('Location: cadastrar_aluno.php');

} else {

    $sql = "UPDATE alunos
                SET ra = ?,
                    nome = ?,
                    sobrenome = ?,
                    curso = ?,
                    email = ?,  
                    cidade = ?,
                    ano_ingresso = ?
                WHERE id = ?";

    if ($db->executa_comando($sql, [$ra, $nome, $sobrenome, $curso, $email, $cidade, $ano_ingresso])) {
        echo "<p>Dados inseridos com sucesso no banco de dados!</p>";
    } else {
        echo "<p>Erro ao inserir os dados no banco.</p>";
    }
    header('Location: alunos.php');

}

$db->desconecta_BD();

?>