<?php

    require_once 'DatabaseMysql.php';

    $nome = $_POST['nome'] ?? 'nome da atividade não foi informardo';
    $descricao = $_POST['descricao'] ?? 'descricao não foi informarda';
    $data_limite = $_POST['data_limite'] ?? 'data não foi informada';
    $flagg = $_GET['flagg'];
    
    $db = new Database();
    
    $flag = $_POST['flag'];
    $id = $_POST['id'];
        
        $sql = "INSERT INTO atividades (
                    nome, descricao, data_limite
                ) VALUES (
                    ?, ?, ?
                )";

        if($db->executa_comando($sql, [$nome, $descricao, $data_limite])){
            echo "<p>Dados inseridos com sucesso no banco de dados!</p>" ;
        } else {
            echo "<p>Erro ao inserir os dados no banco.</p>";
        }
        header('Location: cadastrar_atividade.php');
      
    
    $db->desconecta_BD();
    
?>