<?php

require_once 'DatabaseMysql.php';
$db = new Database();

$id = $_GET['id'];

$sql = "SELECT * FROM alunos WHERE id = :id";
$param = ['id' => $id];

$aluno = $db->Consulta($sql, $param);
$aluno = $aluno[0] ?? null;

?>

<!DOCTYPE html>
<html lang="PT-BR">

<head>
    <meta charset="UTF-8">
    <title>Editar Alunos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Gestão de Atividades</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Alternar navegação">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto"> <!-- Alinhado à direita -->
                    <li class="nav-item">
                    <li class="nav-item">
                        <a class="nav-link" href="cadastrar_atividade.php">Cadastrar Atividade</a>
                    </li>
                    <a class="nav-link" href="cadastrar_atividade.php">Cadastrar Atividade</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cadastrar_aluno.php">Cadastrar Aluno</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="formulario.php">Cadastrar Entrega</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="alunos.php">Lista de Alunos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="listagem_geral.php">Listagem Geral</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="listagem.php">Ranking</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="mb-4">Editar Alunos</h2>
        <form action="processa_aluno.php" method="post">
            <div class="row">
                <input type="hidden" name="id" value="<?= $aluno['id'] ?>">
                <div class="form-group col-md-6">
                    <label for="" class="form-label">Nome</label>
                    <input type="text" class="form-control" name="nome" id="nome" value="<?= $aluno['nome'] ?>">
                </div>
                <div class="form-group col-md-6">
                    <label for="" class="form-label">Sobrenome </label>
                    <input type="text" class="form-control" name="sobrenome" id="sobrenome" required
                        value="<?= $aluno['sobrenome'] ?>">
                </div>
            </div>

            <div class="mb-3" style="margin-top: 15px">
                <label for="email" class="form-label">E-mail</label>
                <input type="text" class="form-control" name="email" id="email" required value="<?= $aluno['email'] ?>">
            </div>

            <div class="row">
                <div class="form-group col-md-6">
                    <label for="" class="form-label">RA</label>
                    <input type="text" class="form-control" name="ra" id="ra" required value="<?= $aluno['ra'] ?>">
                </div>
                <div class="form-group col-md-6">
                    <label for="" class="form-label">Curso</label>
                    <input type="text" class="form-control" name="curso" id="curso" required
                        value="<?= $aluno['curso'] ?>">
                </div>
            </div>

            <div class="row" style="margin-top: 15px">
                <div class="form-group col-md-9">
                    <label for="" class="form-label">Cidade</label>
                    <input type="text" class="form-control" name="cidade" id="cidade" required
                        value="<?= $aluno['cidade'] ?>">
                </div>
                <div class="form-group col-md-3">
                    <label for="" class="form-label">Ano do Ingresso</label>
                    <input type="number" class="form-control" name="ano_ingresso" id="ano_ingresso" required
                        value="<?= $aluno['ano_ingresso'] ?>">
                </div>
            </div>
            <div class="d-flex justify-content-between" style="margin-top: 20px">
                <button type="submit" name="flag" value="A" class="btn btn-primary">Salvar Alterações</button>
            </div>

        </form>
    </div>

</body>

</html>